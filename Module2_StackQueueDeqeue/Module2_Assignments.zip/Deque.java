package DataStructure.Module2_StackQueueDeqeue;

public interface Deque<E>{
    int size();
    boolean isEmpty();
    E first();
    E last();
    void addFirst(E e); 
    void addLast(E e); 
    E removeFirst(E e);
    E removeLast(E e); 
}
